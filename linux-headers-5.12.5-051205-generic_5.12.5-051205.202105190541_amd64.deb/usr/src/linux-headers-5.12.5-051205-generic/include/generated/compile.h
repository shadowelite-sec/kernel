/* This file is auto generated, version 202105190541 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202105190541 SMP Wed May 19 14:00:59 UTC 2021"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "sita"
#define LINUX_COMPILER "gcc (Ubuntu 10.3.0-3ubuntu1) 10.3.0, GNU ld (GNU Binutils for Ubuntu) 2.36.1"
